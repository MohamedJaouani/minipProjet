<?php
    // phpinfo();
    $mailUtilise = false;
    $Json = file_get_contents("comptes.json");
    // Converti en un tableau
    $Tab = json_decode($Json, true);
    $monTab = var_dump($Tab);
    foreach($monTab as $clef => $valeur){
        if($valeur == $mail){
            $mailUtilise = true;
        }
    }
    if($mailUtilise == true){
        //RENVOYER AU AJAX QUE LE MAIL EST UTILISE
    } else {
        //MODIFIER LE JSON, AJOUTER LE MAIL ET LE PASSWORD, MSG DE BIENVENUE

        //DIRECTEMENT CONNECTER LUTILISATEUR OU LE REDIRIGER VERS LA PAGE DE CONNEXION (et donc renvoye un msg genre le compte a été créé) ?? 
        //EST CE QUE LE JSON ON LE CHANGE EN AJOUTANT UNE CHAINE DE CARACTERE ?? GENRE echo '{'.$mail. etc etc
            //AAAH MAIS YA LE TRUC DU MAIL AUSSi
        $json = json_encode(array(
            "email" => $mail,
            "password" => $password
    ));
    }
    
    echo $json;


?>