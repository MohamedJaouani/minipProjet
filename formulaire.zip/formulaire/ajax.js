function Verif_Email(mail,password) {
    $.ajax({
                url: "traitement.php",
                method: "GET",
                data: mail,password,
                dataType: "text",
                success: function(){
                    

                    console.log(mail,password);
                    
                }
            }
    );
    console.log("ok");
};